from accounts.jwt import decode_jwt_token, generate_jwt_token
from django.views.decorators.csrf import csrf_exempt
from rest_framework.decorators import api_view #type: ignore
from rest_framework.response import Response #type: ignore
from .models import User, Subscription
from project import file_operations
import stripe
from django.conf import settings
import requests

def serialize_subscription(subscription):
    return {
        'plan_id': subscription.plan_id,
        'plan_name': subscription.plan_name,
        'project_create': subscription.project_create,
        'add_files': subscription.add_files,
        'file_size': subscription.file_size,
        'multifields': subscription.multifields,
        'chart_plots': subscription.chart_plots,
        'color_selection': subscription.color_selection,
        'custom_theme': subscription.custom_theme,
        'graph_limit': subscription.graph_limit,
        'logs': subscription.logs,
        'chart_download': subscription.chart_download,
        'shares': subscription.shares,
        'pdf_download': subscription.pdf_download
    }




@csrf_exempt
@api_view(['POST'])
def Authentication(request):
    token = request.COOKIES.get('token')
    if token:
        # try:
            JWT_str = decode_jwt_token(token)
            user = User.objects.get(email=JWT_str['email'])
            subscription = Subscription.objects.get(plan_id=user.plan)
            serialized_subscription = serialize_subscription(subscription)

            return Response({
                'message': 'Success',
                'userName': JWT_str['user'], 
                'email':JWT_str['email'], 
                'plan':user.plan,
                'files':user.add_files,
                'chartsDownload':user.chart_download,
                'chartPLot':user.chart_plots,
                'fileSize':user.file_size,
                'graphLimit':user.graph_limit,
                'multifields':user.multifields,
                'projects':user.project_create,
                'shareLimit':user.shares,
                'planData':serialized_subscription
                })
        # except Exception:
        #     return Response({'error': 'Invalid token'})
    else:
        return Response({'error': 'Token not found in cookies'})

    
@api_view(['POST'])
def register(request):
    if request.method == 'POST':
        existing_user = User.objects.filter(
            email=request.data.get('email')).first()
        if existing_user is None:

            user = User(username=request.data.get('name'), email=request.data.get('email'), password=request.data.get('password'), plan=1)

            file_operations.create(user.email)
            
            user.save()
            return Response({'message': 'Successfully Registered'})
        else:
            return Response({'error': 'User with the same email already exists'})
    else:
        return Response({'error': 'Something went wrong'})


@api_view(['POST'])
def google_login(request):
    token = request.data.get('token')
    response = requests.get(f'https://www.googleapis.com/oauth2/v3/tokeninfo?id_token={token}')
    if response.status_code == 200:
        user_info = response.json()
        email = user_info['email']
        name = user_info['name']
        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            user = User(username=name, email=email, google=user_info['sub'], password=f"{email}{user_info['sub']}", plan=1)

            file_operations.create(user.email)
            user.save()
        return Response({'message': 'Successfully logged in with Google'})
    else:
        return Response({'error': 'Failed to authenticate with Google'}, status=400)
    


# def login_with_google(request):
#     return redirect('social:begin', backend='google-oauth2')

# def callback_from_google(request):
#     strategy = load_strategy(request)
#     backend = strategy.backend
#     user = backend.complete(user=request.user)
#     social_user = user.social_auth.get(provider='google-oauth2')

#     existing_user = User.objects.filter(email=user.email).first()

#     if not existing_user:
#         user.username = user.email
#         user.set_password(user.first_name + '@' + social_user.uid)
#         user.save()

#     else:
#         if not existing_user.social_auth.filter(provider='google-oauth2').exists():
#             existing_user.set_password(user.first_name + '@' + social_user.uid)
#             existing_user.save()

#         request.session['user'] = {'name': existing_user.first_name, 'email': existing_user.email}


@api_view(['POST'])
def login(request):
    if request.method == 'POST':
        email = request.data.get('email')
        password = request.data.get('password')
        user = User.objects.filter(email=email).first()

        if user is None:
            return Response({'error': 'User does not exist'})
        
        if user.password == password:
            JWT = generate_jwt_token(user.username, user.email, user.id)

            response = Response({'success': 'Login Successfull.'})
            response.set_cookie('token', JWT, max_age=36000) 
            return response
        else:
            return Response({'error': 'Incorrect password'})
    else:
        return Response({'error': 'Method not allowed'})
    
# @api_view(['POST'])
# def initiate_payment(request):
#     try:
#         plan_id = request.data.get('plan_id')
#         subscription = Subscription.objects.get(plan_id=plan_id)
        
#         stripe.api_key = settings.STRIPE_SECRET_KEY
        
#         checkout_session = stripe.checkout.Session.create(
#             payment_method_types=['card'],
#             line_items=[{
#                 'price_data': {
#                     'currency': 'usd',
#                     'product_data': {
#                         'name': subscription.plan_name,
#                     },
#                     'unit_amount': int(subscription.price * 100),  
#                 },
#                 'quantity': 1,
#             }],
#             mode='subscription',
#             success_url='http://localhost:8000/success?session_id={CHECKOUT_SESSION_ID}',
#             cancel_url='http://localhost:8000/cancel',
#         )
        
#         # Return the session ID to the client
#         return Response({
#             'sessionId': checkout_session.id
#         })
#     except Exception as e:
#         return Response({'error': str(e)}, status=400)
    
@api_view(['GET'])
def logout(request):
    if request.method == 'GET':
        token = request.COOKIES.get('token')
        try:
            user = decode_jwt_token(token)
        except:
            return Response({'error': 'Invalid token'}, status=401)
        if token:
            response = Response({'message': 'Success'})
            response.delete_cookie('token')

            return response
        else:
            return Response({'error': 'Token not found in cookies'})
    else:
        return Response({'error': 'Method not allowed'})
    

@api_view(['POST'])
def updateProfile(request):
    if request.method == 'POST':
        token = request.COOKIES.get('token')
        try:
            user = decode_jwt_token(token)
        except:
            return Response({'error': 'Invalid token'}, status=401)
        name = request.data.get('username')
        email = request.data.get('email')
        password = request.data.get('password')

        if password is None:
            user = User.objects.get(email=email)
            user.username = name
            user.email = email
            user.save()

            return Response({'message': 'Successfully Updated'})
        else:
            user = User.objects.get(email=email)
            user.username = name
            user.email = email
            user.password = password
            user.save()

            return Response({'message': 'Successfully Updated'})
    else:
        return Response({'error': 'Something went wrong'})
    




